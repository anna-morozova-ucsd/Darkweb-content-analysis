"""Test for my functions to be callable """




import pandas as pd
import matplotlib.pyplot as plt


from functions import price, ships_most, receives_most


def test_price():
    assert callable(price)

    
    

def test_ships_most():
    assert callable(ships_most)

    
    
    
def test_receives_most():
    assert callable(receives_most)

    
    





    
    



    



    



                 
    